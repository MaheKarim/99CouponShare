<li class="nav-item">
        <a href="{{ route('showDokan') }}">
                <i class="fas fa-store"></i>
                <p>Dokan</p>
        </a>
</li>
<li class="nav-item">
        <a href="{{ route('showProduct') }}">
            <i class="fab fa-mailchimp"></i>
            <p>Create Product</p>
        </a>
    </li>