@extends('frontend.layout')

@section('content')
  sHoW ALL products
@endsection