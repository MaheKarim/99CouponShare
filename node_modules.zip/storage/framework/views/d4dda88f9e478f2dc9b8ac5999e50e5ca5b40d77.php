<?php $__env->startSection('title'); ?>
    Add Dokan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">
                <?php echo $__env->yieldContent('title','Dokan'); ?>
            </h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                <a href="<?php echo e(url('/home')); ?>">
                        <i class="flaticon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Forms</a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Basic Form</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header text-center">
                        <div class="card-title">Add Dokan Here</div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 col-lg-8">
    
                            <!-- error message -->
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <!-- error message end -->
                            <!-- Notification Start Here -->
                            <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                               <?php endif; ?>
                            <!-- Notification End Here -->
                        <form action="<?php echo e(url('store-dokan')); ?>" method="POST" enctype="multipart/form-data">
                                 <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="text">Add Dokan Name</label>
                                    <input type="text" class="form-control" name="dokan_name" id="text" placeholder="Enter Dokan Name">
                                    <label for="text">Add Dokan Description</label>
                                    <input type="text" class="form-control" name="dokan_description" id="text" placeholder="Enter  Dokan Description">
                                    <label for="text">Choose product Image</label>
                                   <input type="file" class="form-control" name="dokan_image">    
                                </div>
                                </div> 
                            </div>
                        </div>
                        <div class="card-action">
                                <button class="btn btn-success">Submit</button>
                                <a href="<?php echo e(route('showDokan')); ?>" class="btn btn-danger">Cancel</a>
                        </div> 
                       </form>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\99CouponShare\resources\views/backend/dokan/add.blade.php ENDPATH**/ ?>