<li class="nav-item">
        <a href="<?php echo e(route('showDokan')); ?>">
                <i class="fas fa-store"></i>
                <p>Dokan</p>
        </a>
</li>
<li class="nav-item">
        <a href="<?php echo e(route('showProduct')); ?>">
            <i class="fab fa-mailchimp"></i>
            <p>Create Product</p>
        </a>
    </li><?php /**PATH F:\xampp\htdocs\99CouponShare\resources\views/backend/_inc/_sidebar4agent.blade.php ENDPATH**/ ?>