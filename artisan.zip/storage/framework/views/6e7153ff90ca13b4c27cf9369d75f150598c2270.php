<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>
        <?php echo $__env->yieldContent('title', 'Admin | Home Page'); ?>
    </title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="<?php echo e(asset('/')); ?>assets/img/icon.ico" type="image/x-icon"/>


    <script src="https://cdn.ckeditor.com/ckeditor5/15.0.0/classic/ckeditor.js"></script>
	<!-- Fonts and icons -->
	<script src="<?php echo e(asset('/')); ?>assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/atlantis.min.css">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
        <!-- Start Navbar -->
        <?php echo $__env->make('backend._inc._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Navbar -->

        <!-- Start Sidebar -->
		<?php echo $__env->make('backend._inc._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- End Sidebar -->
		<div class="main-panel">
			<div class="content">
		<?php echo $__env->yieldContent('content'); ?>
		
			</div>
		</div>
	</div>
	<?php echo $__env->make('backend._inc._coreOtherJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH F:\xampp\htdocs\99CouponShare\resources\views/backend/_layout.blade.php ENDPATH**/ ?>