<?php $__env->startSection('title'); ?>
    Logo Change
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h4 class="page-title">
            <?php echo $__env->yieldContent('title','Logo Change Option'); ?>
        </h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
            <a href="<?php echo e(url('/home')); ?>">
                    <i class="flaticon-home"></i>
            </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Forms</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Basic Form</a>
            </li>
        </ul>
    </div>
    <hr>
     <!-- Notification Start Here -->
     <?php if(session()->has('success')): ?>
     <div class="alert alert-success">
         <?php echo e(session()->get('success')); ?>

     </div>
        <?php endif; ?>
     <!-- Notification End Here -->
    <div class="col-md-12 col-lg-8">
    <form class="form-group" method="post" action="<?php echo e(route('logoupdate')); ?>"  enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleFormControlFile1">Select a picture for logo</label>
            <small>( Ideal ressolation 440 x 100 ) </small>
            <input type="file" name="logo" class="form-control-file" id="exampleFormControlFile1">
        </div>
    </div>
        <br>
    <div class="card-action">
        <button class="btn btn-success">Submit</button>
    <a href="<?php echo e(url('/home')); ?>" class="btn btn-danger">Cancel</a>
    </div>
</form>
        <hr>
    <!-- Table  Start -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Responsive Table</div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Logo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $logochanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logochange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            
                            <td> <img style="width:100%;max-width:100px" src="<?php echo e(asset('storage')); ?>/<?php echo e($logochange->logo); ?>" /></td> 
                            <td>
                                    <a href="<?php echo e(route('deleteLogo', $logochange->id)); ?>" type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove">
                                            <i class="fa fa-times"></i>
                                    </a>
                            </td> 
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\99CouponShare\resources\views/backend/logo.blade.php ENDPATH**/ ?>