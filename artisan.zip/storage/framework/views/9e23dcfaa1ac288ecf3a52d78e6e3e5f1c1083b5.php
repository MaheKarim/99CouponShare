<?php $__env->startSection('title'); ?>
    Show Contact Req
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">
                <?php echo $__env->yieldContent('title','Show Email Subscriiber List'); ?>
            </h4>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex align-items-center">
                          
                        
                    </div>
                    <div class="card-body">
                    <!-- Modal -->
                        
                                       <!-- Notification Start Here -->
                                       <?php if(session()->has('success')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('success')); ?>

                                       </div>
                                          <?php endif; ?>
                                       <!-- Notification End Here -->

                         <div class="table-responsive">
                            <table id="add-row" class="display table table-striped table-hover" >
                                <thead>
                                    <tr>
                                        <th>Contact Namee</th>
                                        <th>Contact Mail</th>
                                        <th>Contact Web</th>
                                        <th>Contact MSG</th>
                                        <th style="width: 10%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $contactsubmits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactsubmit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($contactsubmit->contact_name); ?></td>
                                    <td><?php echo e($contactsubmit->contact_mail); ?></td>
                                    <td><?php echo e($contactsubmit->contact_web); ?></td>
                                    <td><?php echo e($contactsubmit->contact_msg); ?></td>
                                        <td>
                                            <div class="form-button-action">
                                            <a href="<?php echo e(route('deleteContact', $contactsubmit->id)); ?>" type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove">
                                            <i class="fa fa-times"></i>
                                            </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\99CouponShare\resources\views/backend/contact/show.blade.php ENDPATH**/ ?>