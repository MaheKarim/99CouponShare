<?php $__env->startSection('content'); ?>
<div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Update Page</h4>
           
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Update Shop Here</div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 col-lg-8">
                                <form action="<?php echo e(route('updateDokan')); ?>" method="POST">
                                 <?php echo csrf_field(); ?>
                                <div class="form-group">
                                <label for="text">Update Shop Name</label>
                                <input type="text" class="form-control" name="dokan_name" id="dokan_name" value="<?php echo e($dokans->dokan_name); ?>" placeholder="Enter Dokan Name">
                                <input type="hidden" name="dokan_name_id"  value="<?php echo e($dokans->id); ?>">    
                                <label for="text">Update Shop Description</label>
                                <input type="text" class="form-control" name="dokan_description" id="dokan_description" value="<?php echo e($dokans->dokan_description); ?>" placeholder="Enter Dokan Description">

                                </div>
                                </div> 
                            </div>
                          </div>
                              <div class="card-action">
                                      <button class="btn btn-success">Submit</button>
                              <a href="<?php echo e(url('/show/dokan')); ?>" class="btn btn-danger">Cancel</a>
                        </div> 
                       </form>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\99CouponShare\resources\views/backend/dokan/edit.blade.php ENDPATH**/ ?>