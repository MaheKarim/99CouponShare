<?php $__env->startSection('content'); ?>
<style>
    td.tdCSS{
        /* background-color: aqua; */
        width: 22px;
        height: 20px;
    }
    </style>
<div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">
                <?php echo $__env->yieldContent('title','Show Shop'); ?>
            </h4>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       <?php if(Auth::user()->user_role_id == 2): ?>
                       <div class="d-flex align-items-center">
                            <a href="<?php echo e(route('addDokan')); ?>" class="btn btn-primary btn-round ml-auto">
                                    <i class="fa fa-plus"></i>
                                    Add Shop
                            </a>
                    </div>
                       <?php else: ?>
                           <div class="d-flex align-items-center">
                               
                                <a  class="btn btn-primary btn-round ml-auto text-white">
                                        
                                        Sorry! <b> <?php echo e(Auth::User()->user_role->user_role); ?> </b> Don't Have Permission Here!
                                </a>
                           </div>
                       <?php endif; ?>
                    </div>
                    <div class="card-body">
                    <!-- Modal -->
                        
                                       <!-- Notification Start Here -->
                                       <?php if(session()->has('success')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('success')); ?>

                                       </div>
                                          <?php endif; ?>
                                       <!-- Notification End Here -->
                                       <?php if($errors->any()): ?>
                                       <div class="alert alert-danger">
                                         <ul>
                                             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <li><?php echo e($error); ?></li>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </ul>
                                       </div><br />
                                 <?php endif; ?>
                         <div class="table-responsive">
                            <table id="add-row" class="display table table-striped table-hover" >
                                <thead>
                                    <tr>
                                        <th>Shop Name</th>
                                        <th>Address</th>
                                        <th>Shop Image</th>
                                        <th>Created At</th>
                                        <th style="width: 10%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $dokans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($dokan->dokan_name); ?></td>
                                    <td><?php echo e($dokan->dokan_description); ?></td>
                                    <td class="tdCSS"> <img style="width:100%;max-width:400px" src="<?php echo e(asset('storage')); ?>/<?php echo e($dokan->dokan_image); ?>" /> </td>
                                    <td><?php echo e($dokan->created_at); ?></td>
                                        <td>
                                            <div class="form-button-action">   
                                             <?php if(Auth::user()->user_role_id == 2): ?>
                                             <a href="<?php echo e(route('editDokan', $dokan->id)); ?>" type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                            <a href="<?php echo e(route('deleteDokan', $dokan->id)); ?>" type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                             <?php else: ?>
                                             <a href="<?php echo e(route('deleteDokan', $dokan->id)); ?>" type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                             <?php endif; ?>      
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\99CouponShare\resources\views/backend/dokan/show.blade.php ENDPATH**/ ?>