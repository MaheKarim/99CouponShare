<?php $__env->startSection('title'); ?>
    Add Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h4 class="page-title">
            <?php echo $__env->yieldContent('title','Products'); ?>
        </h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
            <a href="<?php echo e(url('/home')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Forms</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Basic Form</a>
            </li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center">
                    <div class="card-title">Add Products Here</div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 col-lg-8">

                        <!-- error message -->
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <!-- error message end --> 
                        <!-- Notification Start Here -->
                        <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                           <?php endif; ?>
                        <!-- Notification End Here -->
                    <form action="<?php echo e(url('store-products')); ?>" method="POST" enctype="multipart/form-data">
                             <?php echo csrf_field(); ?>
                            <label for="category_name_id">Select Your Category</label>
                            <div class="form-group">
                                    <select class="form-control" name="category_name_id">
                                            <option disabled selected>Select a Category</option>
                                            <?php ( $categories = \App\Category::all()); ?>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                            <div>
                            <label for="area_name_id">Select Your Area</label>
                            <div class="form-group">
                                    <select class="form-control" name="area_name_id">
                                            <option disabled selected>Select a Area</option>
                                            <?php ( $areas = \App\Area::all()); ?>
                                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($area->id); ?>"><?php echo e($area->area_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                            <div>
                            <label for="dokan_name_id">Select Your Shop</label>
                            <div class="form-group">
                                    <select class="form-control" name="dokan_name_id">
                                            <option disabled selected>Select Your Dokan</option>
                                            <?php ( $dokans = \App\Dokan::where('user_id', Auth::id())->get()); ?>
                                            <?php $__currentLoopData = $dokans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dokan->id); ?>"><?php echo e($dokan->dokan_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>   
                            <div>
                                <label for="text">Add Products Name</label>
                                <input type="text" class="form-control" name="product_name" id="text" placeholder="Enter Product Name">
                                <label for="text">Add Products Description</label>
                                <textarea type="text" class="form-control" name="product_description" id="editor" placeholder="Enter Product Description"> </textarea>
                                <label for="text">Product Price</label>
                                <input type="text" class="form-control" name="product_prize" id="text" placeholder="Previous Prize">
                                <label for="text">After Disscount Price</label>
                                <input type="text" class="form-control" name="product_disscount_prize" id="text" placeholder="Disscount Prize">
                                <label for="text">Disscount %</label>
                                <input type="text" class="form-control" name="product_disscount_rate" id="text" placeholder="Disscount %">
                                <label for="text">Coupon Code</label>
                                <input type="text" class="form-control" name="product_coupon" id="text" placeholder="Coupon Code if available">
                                <label for="date">Availibility Date</label>
                                <input type="date" class="form-control" name="availability_date" id="text">    
                                <label for="text">Choose Product Image</label>
                                <input type="file" class="form-control" name="product_image">
                            </div>
                            </div> 
                        </div>
                    </div>
                    <div class="card-action">
                            <button class="btn btn-success">Submit</button>
                            <a href="<?php echo e(route('showProduct')); ?>" class="btn btn-danger">Cancel</a>
                    </div> 
                   </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\99CouponShare\resources\views/backend/products/add.blade.php ENDPATH**/ ?>