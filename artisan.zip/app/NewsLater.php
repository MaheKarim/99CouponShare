<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NewsLater extends Model
{
    protected $guarded = [' '];
}
