<li class="nav-item">
        <a href="{{ route('showDokan') }}">
                <i class="fas fa-store"></i>
                <p>Show Shop</p>
        </a>
</li>
<li class="nav-item">
        <a href="{{ route('showProduct') }}">
            <i class="fab fa-mailchimp"></i>
            <p>Show Product</p>
        </a>
    </li>